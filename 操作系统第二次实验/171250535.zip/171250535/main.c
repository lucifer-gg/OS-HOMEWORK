#include<stdio.h>
#include <stdlib.h>
#include <string.h>

struct DirectoryEntry {
	char DIR_Name[11];//文件名8字节，扩展名3字节
	char DIR_Attr;//文件属性
	char DIR_reserve[10];//保留位（10位）
	short  DIR_WrtTime;//最后一次写入时间
	short  DIR_WrtDate;//最后一次写入日期
	short  DIR_FstClus;//此条目对应的开始簇号
	int  DIR_FileSize;//文件大小
};
struct File {
	char fileName[50];
	int fileType;//1表示文件，0表示目录
	int startClus;//记录文件开始的簇
};
struct DirAndFile {
	int dirDir;
	int dirFile;
};
FILE* file;
struct File files[100];

int countFile = 0;//已经读取了多少个文件
int BytsPerSec = 512;
int SecPerClus = 1;
int ResvdSecCnt = 1;
int NumFATs = 2;
int RootEntCnt = 224;
int FATSz16 = 9;
int BytsPerClus = 512;
int dataStart = 16896;//数据区开始位置dataStart = (ResvdSecCnt + NumFATs * FATSz16 + ((RootEntCnt * 32) + (BytsPerSec - 1)) / BytsPerSec) * BytsPerSec



void my_print(char* c, int length, int color);
void readFat12(FILE* file);
int isName(char name[]);
void getDirName(char res[], char dir[]);
void getFileName(char res[], char file[]);
void addFile(char fileName[], int startClus, int fileType);
void getChildDir(FILE* file, char dir[], int DIR_FstClus);
void printAllChild(FILE* file, char dir[], int DIR_FstClus);
void printinred(char a[]);
void printinwhite(char a[]);
void printRootChild(FILE* file);
struct DirAndFile calDirAndFile(FILE* file, char dir[], int DIR_FstClus);
struct DirAndFile calRootDirAndFile(FILE* file);
void printAllChildWithPara(FILE* file, char dir[], int DIR_FstClus);
void printRootChildWithPara(FILE* file);
int getNextClus(int clus, FILE* file);
void catFile(FILE* file, int DIR_FstClus);
void run(FILE* file);
int getLsPath(char *order, char *res);
int isValidLsPara(char *order);
void printforint(int a);

int main() {
	file = fopen("a.img", "rb");
	readFat12(file);
	run(file);

}
void readFat12(FILE* file) {
	int start = (ResvdSecCnt + NumFATs * FATSz16)*BytsPerSec;
	struct DirectoryEntry dirEntry;
	struct DirectoryEntry* dirEntrypointer = &dirEntry;
	int offset = 0;
	while (offset <= RootEntCnt) {
		fseek(file, start + offset * 32, SEEK_SET);
		fread(dirEntrypointer, 1, 32, file);
		if (!isName(dirEntrypointer->DIR_Name)) {
			offset++;
			continue;
		}
		else {

			if (dirEntrypointer->DIR_Attr == 0x10) {
				char dir[15];
				getDirName(dir, dirEntrypointer->DIR_Name);
				getChildDir(file, dir, dirEntrypointer->DIR_FstClus);

			}
			else {
				char fileName[15];
				getFileName(fileName, dirEntrypointer->DIR_Name);
				char temp1[15];
				strcpy(temp1, "/");
				strcat(temp1, fileName);
				strcat(temp1, "\0");
				char temp[100];
				strcpy(temp, temp1);
				addFile(temp, dirEntrypointer->DIR_FstClus, 1);
			}
			offset++;
		}
	}
}
void printRootChild(FILE* file) {
	printinwhite("/:\n");
	struct File childFiles[16];
	int countChildFile = 0;

	int start = (ResvdSecCnt + NumFATs * FATSz16)*BytsPerSec;
	struct DirectoryEntry dirEntry;
	struct DirectoryEntry* dirEntrypointer = &dirEntry;
	int offset = 0;
	while (offset <= RootEntCnt) {
		fseek(file, start + offset * 32, SEEK_SET);
		fread(dirEntrypointer, 1, 32, file);
		if (!isName(dirEntrypointer->DIR_Name)) {
			offset++;
			continue;
		}
		else {

			if (dirEntrypointer->DIR_Attr == 0x10) {
				char dir[15];
				getDirName(dir, dirEntrypointer->DIR_Name);
				printinred(dir);
				printinwhite("  ");
				struct File childFile;
				strcpy(childFile.fileName, dir);
				childFile.fileType = 0;
				childFile.startClus = dirEntrypointer->DIR_FstClus;
				childFiles[countChildFile] = childFile;
				countChildFile++;


			}
			else {
				char fileName[15];
				getFileName(fileName, dirEntrypointer->DIR_Name);
				printinwhite(fileName);
				printinwhite("  ");

			}
			offset++;
		}
	}
	printinwhite("\n");
	for (int i = 0; i < countChildFile; i++) {
		printAllChild(file, childFiles[i].fileName, childFiles[i].startClus);
	}

}
void printAllChild(FILE* file, char dir[], int DIR_FstClus) {
	struct DirectoryEntry dirEntry;
	struct DirectoryEntry* dirEntrypointer = &dirEntry;
	int offset = 0;
	struct File childFiles[16];
	int countChildFile = 0;


	char temp[100];
	strcpy(temp, "/");
	strcat(temp, dir);
	strcat(temp, "/:");
	strcat(temp, "\0");
	printinwhite(temp);
	printinwhite("\n");
	printinred(".  ..  ");
	while (offset < 16) {//每个簇最多16个文件记录
		fseek(file, dataStart + (DIR_FstClus - 2) * BytsPerClus + (offset * 32), SEEK_SET);
		fread(dirEntrypointer, 1, 32, file);

		if (!isName(dirEntrypointer->DIR_Name)) {
			offset++;
			continue;
		}
		else {

			if (dirEntrypointer->DIR_Attr == 0x10) {
				char sub[15];
				getDirName(sub, dirEntrypointer->DIR_Name);
				printinred(sub);
				printinwhite("  ");
				char temp[100];
				strcpy(temp, dir);
				strcat(temp, "/");
				strcat(temp, sub);
				struct File childFile;
				strcpy(childFile.fileName, temp);
				childFile.fileType = 0;
				childFile.startClus = dirEntrypointer->DIR_FstClus;
				childFiles[countChildFile] = childFile;
				countChildFile++;
			}
			else {
				char fileName[15];
				getFileName(fileName, dirEntrypointer->DIR_Name);
				printinwhite(fileName);
				printinwhite("  ");

			}
			offset++;
		}
	}
	printinwhite("\n");
	for (int i = 0; i < countChildFile; i++) {
		printAllChild(file, childFiles[i].fileName, childFiles[i].startClus);
	}

}
void getChildDir(FILE* file, char dir[], int DIR_FstClus) {
	//读取此路径下的文件名
	struct DirectoryEntry dirEntry;
	struct DirectoryEntry* dirEntrypointer = &dirEntry;
	int offset = 0;


	char temp[100];
	strcpy(temp, "/");
	strcat(temp, dir);
	strcat(temp, "\0");
	addFile(temp, DIR_FstClus, 0);

	while (offset < 16) {//每个簇最多16个文件记录
		fseek(file, dataStart + (DIR_FstClus - 2) * BytsPerClus + (offset * 32), SEEK_SET);
		fread(dirEntrypointer, 1, 32, file);

		if (!isName(dirEntrypointer->DIR_Name)) {
			offset++;
			continue;
		}
		else {

			if (dirEntrypointer->DIR_Attr == 0x10) {
				char sub[15];
				getDirName(sub, dirEntrypointer->DIR_Name);
				char temp[100];
				strcpy(temp, dir);
				strcat(temp, "/");
				strcat(temp, sub);
				getChildDir(file, temp, dirEntrypointer->DIR_FstClus);
			}
			else {
				char fileName[15];
				getFileName(fileName, dirEntrypointer->DIR_Name);
				char temp[100];
				strcpy(temp, "/");
				strcat(temp, dir);
				strcat(temp, "/");
				strcat(temp, fileName);
				strcat(temp, "\0");
				addFile(temp, dirEntrypointer->DIR_FstClus, 1);
			}
			offset++;
		}
	}

}
void addFile(char fileName[], int startClus, int fileType) {
	strcpy(files[countFile].fileName, fileName);
	files[countFile].startClus = startClus;
	files[countFile].fileType = fileType;
	countFile++;
}
int isName(char name[]) {
	for (int i = 0; i < 11; i++) {
		if (!((name[i] >= '0' && name[i] <= '9') || (name[i] >= 'a' && name[i] <= 'z') || (name[i] >= 'A' && name[i] <= 'Z') || name[i] == 0x20)) {
			return 0;
		}
	}
	return 1;
}
void getDirName(char res[], char dir[]) {
	for (int i = 0; i < 12; i++) {
		if (dir[i] == 0x20) {
			res[i] = '\0';
			return;
		}
		else {
			res[i] = dir[i];
		}
	}
}
void getFileName(char res[], char file[]) {
	//文件名
	int i = 0;
	for (i = 0; i < 8; i++) {
		if (file[i] == 0x20) {
			break;
		}
		else {
			res[i] = file[i];
		}
	}
	//扩展名
	res[i] = '.';
	for (int j = 8; j < 11; j++) {
		res[i + 1] = file[j];
		i++;
	}
	res[i + 1] = '\0';
}
void printRootChildWithPara(FILE* file) {
	printinwhite("/ ");
	struct DirAndFile rootDirandFile = calRootDirAndFile(file);
	printforint(rootDirandFile.dirDir);
	printinwhite(" ");
	printforint(rootDirandFile.dirFile);
	printinwhite(":");
	printinwhite("\n");

	struct File childFiles[16];
	int countChildFile = 0;

	int start = (ResvdSecCnt + NumFATs * FATSz16)*BytsPerSec;
	struct DirectoryEntry dirEntry;
	struct DirectoryEntry* dirEntrypointer = &dirEntry;
	int offset = 0;
	while (offset <= RootEntCnt) {
		fseek(file, start + offset * 32, SEEK_SET);
		fread(dirEntrypointer, 1, 32, file);
		if (!isName(dirEntrypointer->DIR_Name)) {
			offset++;
			continue;
		}
		else {

			if (dirEntrypointer->DIR_Attr == 0x10) {
				char dir[15];
				getDirName(dir, dirEntrypointer->DIR_Name);
				printinred(dir);
				printinwhite(" ");
				struct DirAndFile childDirandFile = calDirAndFile(file, dir, dirEntrypointer->DIR_FstClus);
				printforint(childDirandFile.dirDir);
				printinwhite(" ");
				printforint(childDirandFile.dirFile);
				printinwhite("\n");

				struct File childFile;
				strcpy(childFile.fileName, dir);
				childFile.fileType = 0;
				childFile.startClus = dirEntrypointer->DIR_FstClus;
				childFiles[countChildFile] = childFile;
				countChildFile++;


			}
			else {
				char fileName[15];
				getFileName(fileName, dirEntrypointer->DIR_Name);
				printinwhite(fileName);
				printinwhite(" ");
				printforint(dirEntrypointer->DIR_FileSize);
				printinwhite("\n");

			}
			offset++;
		}
	}
	printinwhite("\n");
	for (int i = 0; i < countChildFile; i++) {
		printAllChildWithPara(file, childFiles[i].fileName, childFiles[i].startClus);
	}

}
void printAllChildWithPara(FILE* file, char dir[], int DIR_FstClus) {
	struct DirectoryEntry dirEntry;
	struct DirectoryEntry* dirEntrypointer = &dirEntry;
	int offset = 0;
	struct File childFiles[16];
	int countChildFile = 0;


	char temp[100];
	strcpy(temp, "/");
	strcat(temp, dir);
	strcat(temp, "/");
	strcat(temp, " ");
	printinwhite(temp);
	struct DirAndFile RootDirandFile = calDirAndFile(file, dir, DIR_FstClus);
	printforint(RootDirandFile.dirDir);
	printinwhite(" ");
	printforint(RootDirandFile.dirFile);
	printinwhite(":");
	printinwhite("\n");
	printinred(".\n");
	printinred("..\n");


	while (offset < 16) {//每个簇最多16个文件记录
		fseek(file, dataStart + (DIR_FstClus - 2) * BytsPerClus + (offset * 32), SEEK_SET);
		fread(dirEntrypointer, 1, 32, file);

		if (!isName(dirEntrypointer->DIR_Name)) {
			offset++;
			continue;
		}
		else {

			if (dirEntrypointer->DIR_Attr == 0x10) {
				char sub[15];
				getDirName(sub, dirEntrypointer->DIR_Name);
				printinred(sub);
				char temp[100];
				strcpy(temp, dir);
				strcat(temp, "/");
				strcat(temp, sub);
				struct File childFile;
				strcpy(childFile.fileName, temp);
				childFile.fileType = 0;
				childFile.startClus = dirEntrypointer->DIR_FstClus;
				childFiles[countChildFile] = childFile;
				countChildFile++;
				printinwhite(" ");
				struct DirAndFile childDirandFile = calDirAndFile(file, temp, dirEntrypointer->DIR_FstClus);
				printforint(childDirandFile.dirDir);
				printinwhite(" ");
				printforint(childDirandFile.dirFile);
				printinwhite("\n");
			}
			else {
				char fileName[15];
				getFileName(fileName, dirEntrypointer->DIR_Name);
				printinwhite(fileName);
				printinwhite(" ");
				printforint(dirEntrypointer->DIR_FileSize);
				printinwhite("\n");
			}
			offset++;
		}
	}
	printinwhite("\n");
	for (int i = 0; i < countChildFile; i++) {
		printAllChildWithPara(file, childFiles[i].fileName, childFiles[i].startClus);
	}

}
struct DirAndFile calDirAndFile(FILE* file, char dir[], int DIR_FstClus) {
	struct DirectoryEntry dirEntry;
	struct DirectoryEntry* dirEntrypointer = &dirEntry;
	int offset = 0;

	int countDirFile = 0;
	int countDirDir = 0;


	while (offset < 16) {
		fseek(file, dataStart + (DIR_FstClus - 2) * BytsPerClus + (offset * 32), SEEK_SET);
		fread(dirEntrypointer, 1, 32, file);

		if (!isName(dirEntrypointer->DIR_Name)) {
			offset++;
			continue;
		}
		else {

			if (dirEntrypointer->DIR_Attr == 0x10) {
				countDirDir++;
			}
			else {
				countDirFile++;
			}
			offset++;
		}
	}
	struct DirAndFile daf;
	daf.dirDir = countDirDir;
	daf.dirFile = countDirFile;
	return daf;
}
struct DirAndFile calRootDirAndFile(FILE* file) {
	int countDirFile = 0;
	int countDirDir = 0;
	int start = (ResvdSecCnt + NumFATs * FATSz16)*BytsPerSec;
	struct DirectoryEntry dirEntry;
	struct DirectoryEntry* dirEntrypointer = &dirEntry;
	int offset = 0;
	while (offset <= RootEntCnt) {
		fseek(file, start + offset * 32, SEEK_SET);
		fread(dirEntrypointer, 1, 32, file);
		if (!isName(dirEntrypointer->DIR_Name)) {
			offset++;
			continue;
		}
		else {

			if (dirEntrypointer->DIR_Attr == 0x10) {
				countDirDir++;

			}
			else {
				countDirFile++;
			}
			offset++;
		}
	}
	struct DirAndFile daf;
	daf.dirDir = countDirDir;
	daf.dirFile = countDirFile;
	return daf;
}
void catFile(FILE* file, int DIR_FstClus) {
	int clus = DIR_FstClus;
	char* content = (char*)malloc(512);
	while (clus < 0xFF8) {//大于则表明为最后一个簇
		if (clus == 0xFF7) {//坏簇
			printinwhite("this is a bad classter!\n");
		}
		int seek = dataStart + (clus - 2) * 512;//内容开始位置
		fseek(file, seek, SEEK_SET);
		fread(content, 1, 512, file);

		int offset = 0;
		while (offset < 512) {
			if (content[offset] == '\0') {
				break;
			}
			else {
				char tempchar[2] = { 0 };
				tempchar[0] = content[offset];
				printinwhite(tempchar);
				offset++;
			}
		}
		clus = getNextClus(clus, file);//获取下一个簇；
	}
}
int getNextClus(int clus, FILE* file) {
	unsigned short fatEntry;
	unsigned short* fatEntryPoint = &fatEntry;
	//一个FAT表项存储为3个字节，若为奇数，则取第二个字节起始位置。若为偶数则取第一个字节起始地址
	int fatEntryPos = 512 + clus * 3 / 2;
	fseek(file, fatEntryPos, SEEK_SET);
	fread(fatEntryPoint, 1, 2, file);
	//如果簇号是偶数，取两个字节的低12位
	//如果簇号是奇数，取两个字节的高12位
	if (clus % 2 == 0) {
		return fatEntry & 0xFFF;
	}
	else {
		return fatEntry >> 4;
	}
}
void run(FILE* file) {
	char order[100] = { 0 };
	char orderResv[100] = { 0 };
	while (1) {
		printinwhite("please give you order:\n");
		fgets(order, 100, stdin);
		order[strlen(order) - 1] = '\0';
		strcpy(orderResv, order);
		if (strcmp(order, "exit") == 0) {
			printinwhite("system stop!\n");
			break;
		}
		else {
			char orderTemp[4] = { 0 };
			for (int i = 0; i < 3; i++) {
				orderTemp[i] = order[i];
			}
			if (strcmp(orderTemp, "cat") == 0) {
				//处理cat命令
				char path[50] = { 0 };
				char path1[50] = { 0 };
				int len = strlen(order) - 4;
				strncpy(path1, order + 4, len + 1);
				if (path1[0] != '/') {
					strcpy(path, "/");
					strcat(path, path1);
				}
				else {
					strcpy(path, path1);
				}
				int pathExist = 0;
				for (int i = 0; i < countFile; i++) {
					if (strcmp(files[i].fileName, path) == 0) {
						pathExist = 1;
						if (files[i].fileType == 0) {
							printinwhite("this is a directory！");
							printinwhite("\n");
							break;
						}
						else {
							catFile(file, files[i].startClus);
							printinwhite("\n");
							break;
						}
					}
				}

				if (pathExist == 0) {
					printinwhite("path not exist!");
					printinwhite("\n");
				}

			}
			else {
				char orderTemp2[3] = { 0 };
				for (int i = 0; i < 2; i++) {
					orderTemp2[i] = order[i];
				}

				if (strcmp(orderTemp2, "ls") == 0) {
					//处理ls命令
					int flagofPara = isValidLsPara(order);
					if (flagofPara == 1) {
						printinwhite("parameter wrong!");
						printinwhite("\n");
					}
					else if (flagofPara== 0) {
						//无参数
						char respath[50] = { 0 };
						int pathFlag = getLsPath(orderResv, respath);
						if (pathFlag == 2) {
							printinwhite("path repeat");
							printinwhite("\n");

						}
						else if (pathFlag == 1) {
							int pathExist = 0;
							for (int i = 0; i < countFile; i++) {
								if (strcmp(files[i].fileName, respath) == 0) {
									pathExist = 1;
									if (files[i].fileType == 1) {
										printinwhite("this is a file!");
										printinwhite("\n");
										break;
									}
									else {
										char fileName1[50] = { 0 };
										strncpy(fileName1, files[i].fileName + 1, 40);
										printAllChild(file, fileName1, files[i].startClus);
										break;
									}
								}
							}
							if (pathExist == 0) {
								printinwhite("path not exist!");
								printinwhite("\n");
							}



						}
						else {
							//无参根目录
							printRootChild(file);

						}

					}
					else {
						//有参数
						char respath[50] = { 0 };
						int pathFlag = getLsPath(orderResv, respath);
						if (pathFlag == 2) {
							printinwhite("path repeat!");
							printinwhite("\n");

						}
						else if (pathFlag == 1) {
							int pathExist = 0;
							for (int i = 0; i < countFile; i++) {
								if (strcmp(files[i].fileName, respath) == 0) {
									pathExist = 1;
									if (files[i].fileType == 1) {
										printinwhite("this is a file！");
										printinwhite("\n");
										break;
									}
									else {
										char fileName1[50] = { 0 };
										strncpy(fileName1, files[i].fileName + 1, 40);
										printAllChildWithPara(file, fileName1, files[i].startClus);
										break;
									}
								}
							}
							if (pathExist == 0) {
								printinwhite("path not exist");
								printinwhite("\n");
							}



						}
						else {
							//无参根目录
							printRootChildWithPara(file);

						}
					}
				}
				else {
					//未能识别命令码
					printinwhite("Command code not recognized");
					printinwhite("\n");
				}



			}


		}

	}
}
int getLsPath(char *order, char *res) {//返回0表示没有路径//返回1表示成功获取路径//返回2表示存在重复路径参数
	int indexofres = 0;
	int i;
	char orderTemp[100] = { 0 };
	int indexOfOrderTemp = 0;
	for (i = 0; i < strlen(order)-1; i++) {
		if ((order[i] == ' ')&&(order[i + 1] != '-')&&(order[i+1]!='/')) {
			orderTemp[indexOfOrderTemp] = order[i];
			indexOfOrderTemp++;
			orderTemp[indexOfOrderTemp] = '/';
			indexOfOrderTemp++;
		}
		else {
			orderTemp[indexOfOrderTemp] = order[i];
			indexOfOrderTemp++;
		}
	}

	if (order[strlen(order) - 1] != ' ') {
		orderTemp[indexOfOrderTemp] = order[strlen(order)-1];
		indexOfOrderTemp++;
	}


	for (i = 0; i < strlen(orderTemp); i++) {
		if (orderTemp[i] == '/') {
			break;
		}
	}
	int p = strlen(orderTemp);
	for (int j = i; j < strlen(orderTemp); j++) {
		if ((orderTemp[j] <= 'Z'&&orderTemp[j] >= 'A') || (orderTemp[j] <= '9'&&orderTemp[j] >= '0') || orderTemp[j] == '/' || orderTemp[j] == '.') {
			res[indexofres] = orderTemp[j];
			indexofres++;
		}
		else {
			p = j;
			break;

		}
	}

	for (p; p < strlen(order); p++) {
		if (orderTemp[p] == '/') {
			return 2;
		}
	}

	if (indexofres == 0) {
		return 0;
	}
	else {
		return 1;
	}

}
int isValidLsPara(char *order) {
	//没有参数返回0//参数不合法返回1//参数合法返回2

	int countHG = 0;
	int i = 0;
	for (i = 0; i < strlen(order); i++) {
		if (order[i] == '-') {
			countHG++;
		}
	}

	if (countHG == 0) {
		return 0;
	}
	else if (countHG == 1) {
		for (i = 0; i < strlen(order); i++) {
			if (order[i] == '-') {
				break;
			}
		}

		if (i == strlen(order)) {
			return 0;
		}
		else if (i == (strlen(order) - 1)) {
			return 1;
		}
		else {
			if (order[i + 1] == ' ') {
				return 1;
			}
			for (int j = i + 1; j < strlen(order); j++) {
				if (order[j] == ' ') {
					break;
				}
				else if (order[j] != 'l') {
					return 1;
				}
			}
			return 2;
		}
	}
	else {

		for (i = 0; i < strlen(order); i++) {
			if (order[i] == '-') {
				break;
			}
		}
		order[i] = ' ';

		if (i == strlen(order)) {
			return 0;
		}
		else if (i == (strlen(order) - 1)) {
			return 1;
		}
		else {
			if (order[i + 1] == ' ') {
				return 1;
			}
			for (int j = i + 1; j < strlen(order); j++) {
				if (order[j] == ' ') {
					break;
				}
				else if (order[j] != 'l') {
					return 1;
				}
			}
			return isValidLsPara(order);
		}

	}

}

void printinred(char a[]) {
	my_print(a,strlen(a),1);
	//printf(a);
}
void printinwhite(char a[]) {
	my_print(a,strlen(a),0);
	//printf(a);
}
void printforint(int a) {
	char str[100] = { 0 };
	sprintf(str, "%d", a);
	printinwhite(str);
}
